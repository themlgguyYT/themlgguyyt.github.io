<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="/style.css">
<title>Error - ZombiesCraft</title>
<meta name="description" content="Error Page Dont Exist">
<?php include 'sidebar.php';?>
</head>
<body>
<p><img src="/img/Zombiescraft%20Logo3.png" style="height:250px"></p>
<?php
echo "<tr><h1>sorry no page with path ".$_SERVER['REQUEST_URI']." exists</h1></tr>"
?>
<p><a href="/">click here to go back to the home page</a></p>
</body>
</html>