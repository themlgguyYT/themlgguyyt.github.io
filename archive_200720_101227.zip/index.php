<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="/style.css">
<title>ZombieCraft</title>
<meta name="description" content="ZombiesCraft">
<meta name="theme-color" content="#5d2c85"/>
<?php require 'sidebar.php';?>
</head>
<body>
<p><img src="/img/Zombiescraft%20Logo3.png" style="height:250px"></p>
      <h1 style = "font-family:georgia,garamond,serif;font-size:24px;font-style:italic;">ZombiesCraft</h1>
      <p style = "font-family:georgia,garamond,serif;font-size:16px;font-style:italic;">
         This is demo text
      </p>
</body>
</html>



