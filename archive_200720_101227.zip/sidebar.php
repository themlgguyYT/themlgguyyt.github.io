<style>
  .test {
  position: fixed;
  width: 100px;
  height: 100px;
  right: 5px;    // 5px relative to the most-right of parent
  #}
  #a:link {
  #color: white;
  #background-color: transparent;
  #text-decoration: none;
  #}
  #a:visited {
  #color: white;
  #background-color: transparent;
  #text-decoration: none;
  #}
</style>
<body>
    <div class=test>
        <font size="+2"><p>Social Links</p></font>
        <img src="/img/yt.png" height="20px"><a href="/yt" target="_blank">YT</a><br>
        <img src="/img/discord.png" height="25px"><a href="/discord" target="_blank">Discord</a><br>
        <img src="/img/twitter.png" height="20px"><a href="/twitter" target="_blank">Twitter</a><br>
        <img src="/img/twitch.png" height="25px"><a href="/twitch" target="_blank">Twitch</a><br>
    </div>
</body>